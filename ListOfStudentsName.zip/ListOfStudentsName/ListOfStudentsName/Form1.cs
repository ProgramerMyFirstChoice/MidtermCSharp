﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListOfStudentsName
{
    /*
        Nahom Gebreyohannies 
         
        CSI 154
        January 26 2018
        Code for Using Lists Assignment
         
    */
    public partial class Form1 : Form
    {

        // Create a List to hold names
        List<string> listOfNames = new List<string>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Display(List<string> list)
        {
            // Clear the richbox
            richBoxDisplayList.Clear();

            // Loop thru the list and display it in the richbox
            foreach (string item in list)
            {
                richBoxDisplayList.AppendText(item + "\n");
            }
        }

        private void btnAddToList_Click(object sender, EventArgs e)
        {
            // Check whether user write value in the textbox
            if (!String.IsNullOrEmpty(txtAddItem.Text))
            {
                // Declare and initialize with 0 value
                string name = "";

                // Assign user input to variable name
                name = txtAddItem.Text;

                // Add num to the list
                listOfNames.Add(name);

                // Display the list in a richtextbox
                Display(listOfNames);

                // Make the textbox value to empty
                txtAddItem.Text = "";
            }
            else
            {
                // Display Error message
                MessageBox.Show("Name is reqiured and Letter only allowed");
            }
        }

        private void btnInsertNameToList_Click(object sender, EventArgs e)
        {
            // Check whether user write value in the item textbox
            if (!String.IsNullOrEmpty(txtInsertItem.Text))
            {
                // Check whether user write value in the index textbox
                if (!String.IsNullOrEmpty(txtInsertAtIndex.Text))
                {
                    // Convert user input to integer and assign it to variable
                    string item = txtInsertItem.Text;
                    int index = int.Parse(txtInsertAtIndex.Text);

                    // Check the user input index whether it is postive 
                    // And should be less than number of list
                    if (index >= 0 && index < listOfNames.Count)
                    {
                        // Insert given item at given index 
                        listOfNames.Insert(index, item);
                        MessageBox.Show("item was inserted");
                        // Display the list count and capacity in the label
                        // DisplayCountCapacity();

                        // Display the list in a richtextbox
                        Display(listOfNames);


                        // Make the textbox value to empty
                        txtInsertItem.Text = "";
                        txtInsertAtIndex.Text = "";
                    }
                    else
                    {
                        // Display Error message
                        MessageBox.Show("Index should be greater than 0" +
                                  " Or should be less than a number of the list " + listOfNames.Count, "Invalid index ");
                    }
                }
                else
                {
                    // Display Error message
                    MessageBox.Show("Index number is reqired", "Error Message");
                }
                // Make the textbox value to empty
                

            }
            else
            {
                // Display Error message
                MessageBox.Show("Name is reqiured and only letter allowed", "Error Message");

            }
        }

        private void btnRemoveFromList_Click(object sender, EventArgs e)
        {
            // Check whether user write value in the item textbox
            if (!String.IsNullOrEmpty(txtRemoveItem.Text))
            {
                // Convert user input to integer and assign it to variable
                string name = txtRemoveItem.Text;

                // Remove the user input item and return true or false
                bool done = listOfNames.Remove(name);

                if (done)// if the return from Remove method is true
                {
                    MessageBox.Show("Item was removed");
                    // Display the list count and capacity in the label
                   // DisplayCountCapacity();

                    // Display the list in a richtextbox
                    Display(listOfNames);

                    // Make the textbox value to empty
                    txtRemoveItem.Text = "";

                }
                else
                {
                    // Display Error message
                    MessageBox.Show(name + " could not be removed. It may not exists in the list");
                }

            }
            else
            {
                // Display Error message
                MessageBox.Show("Need to type a number");
            }
        }

        private void btnRemoveAtIndex_Click(object sender, EventArgs e)
        {
            // Check whether user write value in the index textbox
            if (!String.IsNullOrEmpty(txtRemoveAtIndex.Text))
            {
                int index = int.Parse(txtRemoveAtIndex.Text);

                //bool done = integerNumbers.Remove(index);
                if (index >= 0 && index < listOfNames.Count)
                {
                    // Remove the item from the list at the given index
                    listOfNames.RemoveAt(index);

                    // Display the list count and capacity in the label
                    //DisplayCountCapacity();

                    // Display the list in a richtextbox
                    Display(listOfNames);
                    // Make the textbox value to empty
                    txtRemoveAtIndex.Text = "";
                }
                else
                {
                    // Display Error message
                    MessageBox.Show("Index should be greater than 0" +
                              " Or should be less than a number of the list " + listOfNames.Count, "Invalid index ");
                }
            }
            else
            {
                // Display Error message
                MessageBox.Show("Need to type a number");
            }
        }

        // Event that display the lists of name 
        private void btnDisplayList_Click(object sender, EventArgs e)
        {
            Display(listOfNames);
        }

        private void richBoxDisplayList_DoubleClick(object sender, EventArgs e)
        {
            // Clear the list.
            listOfNames.Clear();

            // Display the list count and capacity in the label
          //  DisplayCountCapacity();

            // Display the list in a richtextbox
            Display(listOfNames);
        }

        // When the form loaded the list will have value in the list
        private void Form1_Load(object sender, EventArgs e)
        {
            listOfNames.Add("Nahom");
            listOfNames.Add("Tedros");
            listOfNames.Add("Tomas");
            listOfNames.Add("Yared");
            listOfNames.Add("Ibrahim");
            listOfNames.Add("Mensur");
            listOfNames.Add("Zena");
            listOfNames.Add("Thompson");
            listOfNames.Add("Robert");
            listOfNames.Add("Gazra");
        }
        #region Method for keypress 
                // Allow only letters , space, and back key from keyboard
                private void txtAddItem_KeyPress(object sender, KeyPressEventArgs e)
                {
                    KeyPressForLetteronly(e);

                }
                // Allow only letters , space, and back key from keyboard
                private void txtRemoveItem_KeyPress(object sender, KeyPressEventArgs e)
                {

                    KeyPressForLetteronly(e);
                }

                // Allow only letters , space, and back key from keyboard
                private void txtInsertItem_KeyPress(object sender, KeyPressEventArgs e)
                {
                    KeyPressForLetteronly(e);
                }

                // Method that allow only letter when the keyboard press value to textbox
                private static void KeyPressForLetteronly(KeyPressEventArgs e)
                {
                    e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back ||
                        e.KeyChar == (char)Keys.Space);
                }

            }
        #endregion
}
