﻿namespace ListOfStudentsName
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtAddItem = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddToList = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtRemoveAtIndex = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRemoveAtIndex = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtRemoveItem = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnRemoveFromList = new System.Windows.Forms.Button();
            this.btnDisplayList = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtInsertAtIndex = new System.Windows.Forms.TextBox();
            this.txtInsertItem = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnInsertNameToList = new System.Windows.Forms.Button();
            this.richBoxDisplayList = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.txtAddItem);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnAddToList);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(310, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(222, 167);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add Item";
            // 
            // txtAddItem
            // 
            this.txtAddItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddItem.Location = new System.Drawing.Point(50, 51);
            this.txtAddItem.Name = "txtAddItem";
            this.txtAddItem.Size = new System.Drawing.Size(153, 26);
            this.txtAddItem.TabIndex = 2;
            this.txtAddItem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAddItem_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "item";
            // 
            // btnAddToList
            // 
            this.btnAddToList.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddToList.Location = new System.Drawing.Point(17, 108);
            this.btnAddToList.Name = "btnAddToList";
            this.btnAddToList.Size = new System.Drawing.Size(186, 34);
            this.btnAddToList.TabIndex = 0;
            this.btnAddToList.Text = "Add item to List";
            this.btnAddToList.UseVisualStyleBackColor = true;
            this.btnAddToList.Click += new System.EventHandler(this.btnAddToList_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox4.Controls.Add(this.txtRemoveAtIndex);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.btnRemoveAtIndex);
            this.groupBox4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(553, 186);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(222, 167);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Remove Item At Index";
            // 
            // txtRemoveAtIndex
            // 
            this.txtRemoveAtIndex.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemoveAtIndex.Location = new System.Drawing.Point(56, 49);
            this.txtRemoveAtIndex.Name = "txtRemoveAtIndex";
            this.txtRemoveAtIndex.Size = new System.Drawing.Size(153, 26);
            this.txtRemoveAtIndex.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "index";
            // 
            // btnRemoveAtIndex
            // 
            this.btnRemoveAtIndex.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveAtIndex.Location = new System.Drawing.Point(23, 94);
            this.btnRemoveAtIndex.Name = "btnRemoveAtIndex";
            this.btnRemoveAtIndex.Size = new System.Drawing.Size(186, 34);
            this.btnRemoveAtIndex.TabIndex = 0;
            this.btnRemoveAtIndex.Text = "Remove Name At Index";
            this.btnRemoveAtIndex.UseVisualStyleBackColor = true;
            this.btnRemoveAtIndex.Click += new System.EventHandler(this.btnRemoveAtIndex_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.txtRemoveItem);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btnRemoveFromList);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(310, 186);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(222, 167);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Remove Item";
            // 
            // txtRemoveItem
            // 
            this.txtRemoveItem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemoveItem.Location = new System.Drawing.Point(62, 37);
            this.txtRemoveItem.Name = "txtRemoveItem";
            this.txtRemoveItem.Size = new System.Drawing.Size(153, 26);
            this.txtRemoveItem.TabIndex = 2;
            this.txtRemoveItem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRemoveItem_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "item";
            // 
            // btnRemoveFromList
            // 
            this.btnRemoveFromList.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemoveFromList.Location = new System.Drawing.Point(30, 94);
            this.btnRemoveFromList.Name = "btnRemoveFromList";
            this.btnRemoveFromList.Size = new System.Drawing.Size(186, 34);
            this.btnRemoveFromList.TabIndex = 0;
            this.btnRemoveFromList.Text = "Remove Name From List";
            this.btnRemoveFromList.UseVisualStyleBackColor = true;
            this.btnRemoveFromList.Click += new System.EventHandler(this.btnRemoveFromList_Click);
            // 
            // btnDisplayList
            // 
            this.btnDisplayList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayList.Location = new System.Drawing.Point(12, 348);
            this.btnDisplayList.Name = "btnDisplayList";
            this.btnDisplayList.Size = new System.Drawing.Size(291, 43);
            this.btnDisplayList.TabIndex = 4;
            this.btnDisplayList.Text = "Display the names";
            this.btnDisplayList.UseVisualStyleBackColor = true;
            this.btnDisplayList.Click += new System.EventHandler(this.btnDisplayList_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.groupBox3.Controls.Add(this.txtInsertAtIndex);
            this.groupBox3.Controls.Add(this.txtInsertItem);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.btnInsertNameToList);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(553, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(222, 167);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Insert Item";
            // 
            // txtInsertAtIndex
            // 
            this.txtInsertAtIndex.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInsertAtIndex.Location = new System.Drawing.Point(56, 64);
            this.txtInsertAtIndex.Name = "txtInsertAtIndex";
            this.txtInsertAtIndex.Size = new System.Drawing.Size(153, 26);
            this.txtInsertAtIndex.TabIndex = 2;
            // 
            // txtInsertItem
            // 
            this.txtInsertItem.Location = new System.Drawing.Point(56, 29);
            this.txtInsertItem.Name = "txtInsertItem";
            this.txtInsertItem.Size = new System.Drawing.Size(153, 26);
            this.txtInsertItem.TabIndex = 2;
            this.txtInsertItem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInsertItem_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 19);
            this.label6.TabIndex = 1;
            this.label6.Text = "index";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 19);
            this.label7.TabIndex = 1;
            this.label7.Text = "item";
            // 
            // btnInsertNameToList
            // 
            this.btnInsertNameToList.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsertNameToList.Location = new System.Drawing.Point(23, 108);
            this.btnInsertNameToList.Name = "btnInsertNameToList";
            this.btnInsertNameToList.Size = new System.Drawing.Size(186, 34);
            this.btnInsertNameToList.TabIndex = 0;
            this.btnInsertNameToList.Text = "Insert Name to List";
            this.btnInsertNameToList.UseVisualStyleBackColor = true;
            this.btnInsertNameToList.Click += new System.EventHandler(this.btnInsertNameToList_Click);
            // 
            // richBoxDisplayList
            // 
            this.richBoxDisplayList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richBoxDisplayList.Location = new System.Drawing.Point(12, 12);
            this.richBoxDisplayList.Name = "richBoxDisplayList";
            this.richBoxDisplayList.ReadOnly = true;
            this.richBoxDisplayList.Size = new System.Drawing.Size(291, 329);
            this.richBoxDisplayList.TabIndex = 5;
            this.richBoxDisplayList.Text = "";
            this.richBoxDisplayList.DoubleClick += new System.EventHandler(this.richBoxDisplayList_DoubleClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(787, 405);
            this.Controls.Add(this.richBoxDisplayList);
            this.Controls.Add(this.btnDisplayList);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtAddItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddToList;
        private System.Windows.Forms.Button btnRemoveAtIndex;
        private System.Windows.Forms.TextBox txtRemoveItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnRemoveFromList;
        private System.Windows.Forms.Button btnDisplayList;
        private System.Windows.Forms.TextBox txtRemoveAtIndex;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtInsertAtIndex;
        private System.Windows.Forms.TextBox txtInsertItem;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnInsertNameToList;
        private System.Windows.Forms.RichTextBox richBoxDisplayList;
    }
}

