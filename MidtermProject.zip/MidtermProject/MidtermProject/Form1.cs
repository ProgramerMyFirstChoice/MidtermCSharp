﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermProject
{
    public partial class Form1 : System.Windows.Forms.Form
    {
       /* Nahom Gebreyohannies
      
          February 7, 2018
          This code is for Midterm Project
          CSI 154
         */

        public Form1()
        {
            InitializeComponent();
        }
     
        private void btnOrder_Click(object sender, EventArgs e)
        {
            // Declare variable             
            decimal subTotal = 0m;
            const decimal STATETAX = 0.09M; // State tax
            const decimal TOPPING_PRICE = 1.99M; // Topping price
            const decimal PIZZA_PRICE = 10.99M; // Including 3 toppings


            // Declare variable to hold number of checked checkbox
            int checkedCount = 0;

            // Iterate through all of the Controls in groupbox 
            foreach (Control chk in gbxToppings.Controls)
            {
                // If one of the Controls is a CheckBox and it is checked
                // then increment your count
                if (chk is CheckBox && (chk as CheckBox).Checked)
                {
                    checkedCount++;
                }
            }

            // Find the subTotal of the selected pizza price 
            // using CalculatePizzaPrice
            subTotal = CalculatePizzaPrice (TOPPING_PRICE, PIZZA_PRICE, checkedCount);

            // Calculate the sale tax
            decimal salesTax = subTotal * STATETAX;

            // Calculate the total cost
            decimal total = subTotal + salesTax;

            // Display the subTotal, salesTax, and total
            lblNamOutPut.Text = txtName.Text;
            txtSubTotal.Text = subTotal.ToString("C");
            txtTax.Text = salesTax.ToString("C");
            txtTotal.Text = total.ToString("C");
        }  
        
        private void btnWrite_Click(object sender, EventArgs e)
        {
            
            // Declare a StreamWriter variable
            StreamWriter outputFile;

            // Create a file and get a StreamWriter object.
            outputFile = File.AppendText("FilesCS.txt");

            // Call the method that return selected radio button's text
            // and assign it to string variable 
            string radioButtunValue = GetSelectedRadioButtonText(gbxTodaySpecials);

            // Write the name of customer and radio button's text to the text file
            outputFile.WriteLine(txtName.Text + " " + radioButtunValue);
            
            // loop thru the checkbox
            foreach (CheckBox cmb in gbxToppings.Controls)
            {
                // check the checkbox whether it is selected
                if (cmb.Checked)
                {
                    // Assign the selected checkbox's text to variable
                    string chkname = cmb.Text;

                    // Write the selected checkbox's text to the text file
                    outputFile.Write(chkname + ", ");
                }

            }

            // Write the array's content to the file.
            outputFile.WriteLine("\n" + txtSubTotal.Text + "\t" +
                txtTax.Text + "\t" + txtTotal.Text);
            

            // Close the StreamWriter
            outputFile.Close();

            // Let the user know the array values was written
            MessageBox.Show("Done");

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        #region CalculatePizzaPrice,GetSelectedRadioButtonText,TodaySpecials_CheckedChanged Methods
        // Method accepts groupbox as a parameter and return 
        // selected radio button's text
        private string GetSelectedRadioButtonText(GroupBox grb)
        {
            return grb.Controls.OfType<RadioButton>().SingleOrDefault(rad => rad.Checked == true).Text;
        }

        // If hamburger selected calculate the subtotal
        // Using the checkedCount,  and tax
        private decimal CalculatePizzaPrice(decimal TOPPING_PRICE, decimal PIZZA_PRICE, int checkedCount)
        {
            decimal subTotal;
            if (radioMeat.Checked && checkedCount > 3)
            {
                subTotal = PIZZA_PRICE + ((checkedCount-3) * TOPPING_PRICE);
            }
            else if (radioVeggie.Checked && checkedCount > 3)
            {
                subTotal = PIZZA_PRICE + ((checkedCount - 3) * TOPPING_PRICE);
            }
            else if (radioSupreme.Checked && checkedCount > 3)
            {
                subTotal = PIZZA_PRICE + ((checkedCount - 3) * TOPPING_PRICE);
            }
            else
            {
                subTotal = 10.99m;
            }

            return subTotal;
        }

        private void TodaySpecials_CheckedChanged(object sender, EventArgs e)
        {
            // When the Meat selected clear the checkbox
            // And checked the Ham, Chicken, and Pepperoni topping checkbox
            if (radioMeat.Checked)
            {
                ClearAddOns();
                chkHamTopping.Checked = true;
                chkChikenTopping.Checked = true;
                chkPepperoniTopping.Checked = true;
            }
            // When the Supreme selected clear the checkbox
            // And checked the Beef, Pork, and Mushrooms topping checkbox
            else if (radioSupreme.Checked)
            {
                ClearAddOns();
                chkBeefTopping.Checked = true;
                chkPorkTopping.Checked = true;
                chkMushroomTopping.Checked = true;
            }
            // When the Veggie Lover selected clear the checkbox
            // And checked the Peppers, Onion, and Spinach topping checkbox
            else if (radioVeggie.Checked)
            {
                ClearAddOns();
                chkPeppersTopping.Checked = true;
                chkOnionTopping.Checked = true;
                chkSpinachTopping.Checked = true;
            }
            
        }

        // Method to clear Textbox
        private void ClearTotals()
        {
            txtSubTotal.Text = "";
            txtTax.Text = "";
            txtTotal.Text = "";
            lblNamOutPut.Text = "";
        }
      
        // Method to clear the checkbox
        private void ClearAddOns()
        {
            chkChikenTopping.Checked = false;
            chkPepperoniTopping.Checked = false;
            chkHamTopping.Checked = false;
            chkMushroomTopping.Checked = false;
            chkOnionTopping.Checked = false;
            chkPeppersTopping.Checked = false;
            chkBeefTopping.Checked = false;
            chkPorkTopping.Checked = false;
            chkSpinachTopping.Checked = false;
            chkPurCherryTopping.Checked = false;
        }
        #endregion
    }

    // var scount = gbxToppings.Controls.OfType<CheckBox>().Count(c => c.Checked);
}
