﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermProject
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        /* Nahom Gebreyohannies

           February 7, 2018
           This code is for Midterm Project
           CSI 154
          */
        List<string> allTopping = new List<string>();

        public Form1()
        {
            InitializeComponent();
            allTopping.Add("Chicken");
            allTopping.Add("Pepperoni");
            allTopping.Add("HamTopping");
            allTopping.Add("Mushroom");
            allTopping.Add("Red Onion");
            allTopping.Add("Peppers");
            allTopping.Add("Beef");
            allTopping.Add("Pork");
            allTopping.Add("Roasted Spinach");
            allTopping.Add("Peruvian Cherry Peppers");
        }
        

        // list to hold the selected toppings for selected pizza order
        List<string> orderTops = new List<string>();

        string radioButtonText;

        private void btnOrder_Click(object sender, EventArgs e)
        {
            // Declare variable             
            decimal subTotal = 0m;          
            const decimal STATETAX = 0.09M; // State tax
            const decimal TOPPING_PRICE = 1.99M; // Topping price
            const decimal PIZZA_PRICE = 10.99M; // Including 3 toppings
            
            int addOns = 0;
            // When the checkbox selected add the text to list
            // And assign the the number of selection to variable           
            if (chkChikenTopping.Checked)
            {
                orderTops.Add(chkChikenTopping.Text);
                addOns += 1;
            }
            if (chkPepperoniTopping.Checked)
            {
                orderTops.Add(chkPepperoniTopping.Text);
                addOns += 1;
            }
            if (chkHamTopping.Checked)
            {
                orderTops.Add(chkHamTopping.Text);
                addOns += 1;
            }
            if (chkMushroomTopping.Checked)
            {
                orderTops.Add(chkMushroomTopping.Text);
                addOns += 1;
            }
            if (chkOnionTopping.Checked)
            {
                orderTops.Add(chkOnionTopping.Text);
                addOns += 1;
            }
            if (chkPeppersTopping.Checked)
            {
                orderTops.Add(chkPeppersTopping.Text);
                addOns += 1;
            }

            if (chkBeefTopping.Checked)
            {
                orderTops.Add(chkBeefTopping.Text);
                addOns += 1;
            }
            if (chkPorkTopping.Checked)
            {
                orderTops.Add(chkPorkTopping.Text);
                addOns += 1;
            }
            if (chkSpinachTopping.Checked)
            {
                orderTops.Add(chkSpinachTopping.Text);
                addOns += 1;
            }
            if (chkPurCherryTopping.Checked)
            {
                orderTops.Add(chkPurCherryTopping.Text);
                addOns += 1;
            }

            // When the radiobutton selected assign the text of radiobutton
            //  a variable radioButtonText
            if (radioMeat.Checked)
            {
                radioButtonText = radioMeat.Text;
            }
            else if (radioVeggie.Checked)
            {
                radioButtonText = radioVeggie.Text;

            }
            else if (radioSupreme.Checked)
            {
                radioButtonText = radioSupreme.Text;
            }

            // Find the subTotal of the selected pizza price 
            // using CalculatePizzaPrice
            if ((radioMeat.Checked || radioVeggie.Checked || radioSupreme.Checked) && addOns > 3)
            {
                subTotal = PIZZA_PRICE + ((addOns - 3) * TOPPING_PRICE);
            }
            
            else
            {
                subTotal = 10.99m;
            }

            // Calculate the sale tax
            decimal salesTax = subTotal * STATETAX;

            // Calculate the total cost
            decimal total = subTotal + salesTax;

            // Display the subTotal, salesTax, and total
            lblNamOutPut.Text = txtName.Text;
            txtSubTotal.Text = subTotal.ToString("C");
            txtTax.Text = salesTax.ToString("C");
            txtTotal.Text = total.ToString("C");
        }  
        
        private void btnWrite_Click(object sender, EventArgs e)
        {
            

            // Declare a StreamWriter variable
            StreamWriter outputFile;

            // Create a file and get a StreamWriter object.
            outputFile = File.AppendText("FilesCS.txt");

           

            // Write the name of customer and radio button's text to the text file
            outputFile.WriteLine(txtName.Text + " " + radioButtonText);


            foreach (string chkText in orderTops)
            {
                outputFile.Write(chkText + ", ");
            }
            

            // Write the calcualted value content to the file.
            outputFile.WriteLine("\n" + txtSubTotal.Text + "\t" +
                txtTax.Text + "\t" + txtTotal.Text);

            // Clear the orderTops selected checkbox text
            orderTops.Clear();

            // Close the StreamWriter
            outputFile.Close();

            // Let the user know the array values was written
            MessageBox.Show("Done");

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        #region TodaySpecials_CheckedChanged, Clear the Textbox, and Clear the checkBox Methods
       

        private void TodaySpecials_CheckedChanged(object sender, EventArgs e)
        {
            // When the Meat selected clear the checkbox
            // And checked the Ham, Chicken, and Pepperoni topping checkbox
            if (radioMeat.Checked)
            {
                ClearAddOns();
                chkHamTopping.Checked = true;
                chkChikenTopping.Checked = true;
                chkPepperoniTopping.Checked = true;
            }
            // When the Supreme selected clear the checkbox
            // And checked the Beef, Pork, and Mushrooms topping checkbox
            else if (radioSupreme.Checked)
            {
                ClearAddOns();
                chkBeefTopping.Checked = true;
                chkPorkTopping.Checked = true;
                chkMushroomTopping.Checked = true;
            }
            // When the Veggie Lover selected clear the checkbox
            // And checked the Peppers, Onion, and Spinach topping checkbox
            else if (radioVeggie.Checked)
            {
                ClearAddOns();
                chkPeppersTopping.Checked = true;
                chkOnionTopping.Checked = true;
                chkSpinachTopping.Checked = true;
            }
            
        }

        // Method to clear Textbox
        private void ClearTotals()
        {
            txtSubTotal.Text = "";
            txtTax.Text = "";
            txtTotal.Text = "";
            lblNamOutPut.Text = "";
        }
      
        // Method to clear the checkbox
        private void ClearAddOns()
        {
            chkChikenTopping.Checked = false;
            chkPepperoniTopping.Checked = false;
            chkHamTopping.Checked = false;
            chkMushroomTopping.Checked = false;
            chkOnionTopping.Checked = false;
            chkPeppersTopping.Checked = false;
            chkBeefTopping.Checked = false;
            chkPorkTopping.Checked = false;
            chkSpinachTopping.Checked = false;
            chkPurCherryTopping.Checked = false;
        }
        #endregion

        private void Form1_Load(object sender, EventArgs e)
        {
            // Display the text in checkBox text property
            // When the form loaded
            chkChikenTopping.Text = allTopping[0];
            chkPepperoniTopping.Text = allTopping[1];
            chkHamTopping.Text = allTopping[2];
            chkMushroomTopping.Text = allTopping[3];
            chkOnionTopping.Text = allTopping[4];
            chkPeppersTopping.Text = allTopping[5];
            chkBeefTopping.Text = allTopping[6];
            chkPorkTopping.Text = allTopping[7];          
            chkSpinachTopping.Text = allTopping[8];
            chkPurCherryTopping.Text = allTopping[9];         
        }
    }

   
}
