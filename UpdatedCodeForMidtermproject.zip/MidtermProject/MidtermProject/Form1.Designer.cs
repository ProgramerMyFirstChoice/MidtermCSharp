﻿namespace MidtermProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.gbxTodaySpecials = new System.Windows.Forms.GroupBox();
            this.radioSupreme = new System.Windows.Forms.RadioButton();
            this.radioVeggie = new System.Windows.Forms.RadioButton();
            this.radioMeat = new System.Windows.Forms.RadioButton();
            this.gbxToppings = new System.Windows.Forms.GroupBox();
            this.chkPorkTopping = new System.Windows.Forms.CheckBox();
            this.chkPurCherryTopping = new System.Windows.Forms.CheckBox();
            this.chkOnionTopping = new System.Windows.Forms.CheckBox();
            this.chkSpinachTopping = new System.Windows.Forms.CheckBox();
            this.chkMushroomTopping = new System.Windows.Forms.CheckBox();
            this.chkBeefTopping = new System.Windows.Forms.CheckBox();
            this.chkHamTopping = new System.Windows.Forms.CheckBox();
            this.chkPeppersTopping = new System.Windows.Forms.CheckBox();
            this.chkPepperoniTopping = new System.Windows.Forms.CheckBox();
            this.chkChikenTopping = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnOrder = new System.Windows.Forms.Button();
            this.lblNamOutPut = new System.Windows.Forms.Label();
            this.btnWrite = new System.Windows.Forms.Button();
            this.gbxTodaySpecials.SuspendLayout();
            this.gbxToppings.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Name:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(16, 38);
            this.txtName.Margin = new System.Windows.Forms.Padding(5);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(247, 26);
            this.txtName.TabIndex = 0;
            // 
            // gbxTodaySpecials
            // 
            this.gbxTodaySpecials.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.gbxTodaySpecials.Controls.Add(this.radioSupreme);
            this.gbxTodaySpecials.Controls.Add(this.radioVeggie);
            this.gbxTodaySpecials.Controls.Add(this.radioMeat);
            this.gbxTodaySpecials.Controls.Add(this.gbxToppings);
            this.gbxTodaySpecials.Location = new System.Drawing.Point(14, 75);
            this.gbxTodaySpecials.Margin = new System.Windows.Forms.Padding(5);
            this.gbxTodaySpecials.Name = "gbxTodaySpecials";
            this.gbxTodaySpecials.Padding = new System.Windows.Forms.Padding(5);
            this.gbxTodaySpecials.Size = new System.Drawing.Size(612, 303);
            this.gbxTodaySpecials.TabIndex = 2;
            this.gbxTodaySpecials.TabStop = false;
            this.gbxTodaySpecials.Text = "Today\'s Specials";
            // 
            // radioSupreme
            // 
            this.radioSupreme.AutoSize = true;
            this.radioSupreme.Location = new System.Drawing.Point(426, 29);
            this.radioSupreme.Margin = new System.Windows.Forms.Padding(5);
            this.radioSupreme.Name = "radioSupreme";
            this.radioSupreme.Size = new System.Drawing.Size(99, 24);
            this.radioSupreme.TabIndex = 1;
            this.radioSupreme.TabStop = true;
            this.radioSupreme.Text = "Supreme";
            this.radioSupreme.UseVisualStyleBackColor = true;
            this.radioSupreme.CheckedChanged += new System.EventHandler(this.TodaySpecials_CheckedChanged);
            // 
            // radioVeggie
            // 
            this.radioVeggie.AutoSize = true;
            this.radioVeggie.Location = new System.Drawing.Point(228, 29);
            this.radioVeggie.Margin = new System.Windows.Forms.Padding(5);
            this.radioVeggie.Name = "radioVeggie";
            this.radioVeggie.Size = new System.Drawing.Size(148, 24);
            this.radioVeggie.TabIndex = 1;
            this.radioVeggie.TabStop = true;
            this.radioVeggie.Text = "Garden Veggie";
            this.radioVeggie.UseVisualStyleBackColor = true;
            this.radioVeggie.CheckedChanged += new System.EventHandler(this.TodaySpecials_CheckedChanged);
            // 
            // radioMeat
            // 
            this.radioMeat.AutoSize = true;
            this.radioMeat.Location = new System.Drawing.Point(69, 29);
            this.radioMeat.Margin = new System.Windows.Forms.Padding(5);
            this.radioMeat.Name = "radioMeat";
            this.radioMeat.Size = new System.Drawing.Size(125, 24);
            this.radioMeat.TabIndex = 1;
            this.radioMeat.TabStop = true;
            this.radioMeat.Text = "Meat Lovers";
            this.radioMeat.UseVisualStyleBackColor = true;
            this.radioMeat.CheckedChanged += new System.EventHandler(this.TodaySpecials_CheckedChanged);
            // 
            // gbxToppings
            // 
            this.gbxToppings.BackColor = System.Drawing.Color.Red;
            this.gbxToppings.Controls.Add(this.chkPorkTopping);
            this.gbxToppings.Controls.Add(this.chkPurCherryTopping);
            this.gbxToppings.Controls.Add(this.chkOnionTopping);
            this.gbxToppings.Controls.Add(this.chkSpinachTopping);
            this.gbxToppings.Controls.Add(this.chkMushroomTopping);
            this.gbxToppings.Controls.Add(this.chkBeefTopping);
            this.gbxToppings.Controls.Add(this.chkHamTopping);
            this.gbxToppings.Controls.Add(this.chkPeppersTopping);
            this.gbxToppings.Controls.Add(this.chkPepperoniTopping);
            this.gbxToppings.Controls.Add(this.chkChikenTopping);
            this.gbxToppings.Location = new System.Drawing.Point(24, 74);
            this.gbxToppings.Margin = new System.Windows.Forms.Padding(5);
            this.gbxToppings.Name = "gbxToppings";
            this.gbxToppings.Padding = new System.Windows.Forms.Padding(5);
            this.gbxToppings.Size = new System.Drawing.Size(542, 216);
            this.gbxToppings.TabIndex = 0;
            this.gbxToppings.TabStop = false;
            this.gbxToppings.Text = "Toppings";
            // 
            // chkPorkTopping
            // 
            this.chkPorkTopping.AutoSize = true;
            this.chkPorkTopping.Location = new System.Drawing.Point(272, 101);
            this.chkPorkTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkPorkTopping.Name = "chkPorkTopping";
            this.chkPorkTopping.Size = new System.Drawing.Size(15, 14);
            this.chkPorkTopping.TabIndex = 0;
            this.chkPorkTopping.UseVisualStyleBackColor = true;
            // 
            // chkPurCherryTopping
            // 
            this.chkPurCherryTopping.AutoSize = true;
            this.chkPurCherryTopping.Location = new System.Drawing.Point(272, 170);
            this.chkPurCherryTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkPurCherryTopping.Name = "chkPurCherryTopping";
            this.chkPurCherryTopping.Size = new System.Drawing.Size(15, 14);
            this.chkPurCherryTopping.TabIndex = 0;
            this.chkPurCherryTopping.UseVisualStyleBackColor = true;
            // 
            // chkOnionTopping
            // 
            this.chkOnionTopping.AutoSize = true;
            this.chkOnionTopping.Location = new System.Drawing.Point(19, 170);
            this.chkOnionTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkOnionTopping.Name = "chkOnionTopping";
            this.chkOnionTopping.Size = new System.Drawing.Size(15, 14);
            this.chkOnionTopping.TabIndex = 0;
            this.chkOnionTopping.UseVisualStyleBackColor = true;
            // 
            // chkSpinachTopping
            // 
            this.chkSpinachTopping.AutoSize = true;
            this.chkSpinachTopping.Location = new System.Drawing.Point(272, 135);
            this.chkSpinachTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkSpinachTopping.Name = "chkSpinachTopping";
            this.chkSpinachTopping.Size = new System.Drawing.Size(15, 14);
            this.chkSpinachTopping.TabIndex = 0;
            this.chkSpinachTopping.UseVisualStyleBackColor = true;
            // 
            // chkMushroomTopping
            // 
            this.chkMushroomTopping.AutoSize = true;
            this.chkMushroomTopping.Location = new System.Drawing.Point(19, 135);
            this.chkMushroomTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkMushroomTopping.Name = "chkMushroomTopping";
            this.chkMushroomTopping.Size = new System.Drawing.Size(15, 14);
            this.chkMushroomTopping.TabIndex = 0;
            this.chkMushroomTopping.UseVisualStyleBackColor = true;
            // 
            // chkBeefTopping
            // 
            this.chkBeefTopping.AutoSize = true;
            this.chkBeefTopping.Location = new System.Drawing.Point(272, 64);
            this.chkBeefTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkBeefTopping.Name = "chkBeefTopping";
            this.chkBeefTopping.Size = new System.Drawing.Size(15, 14);
            this.chkBeefTopping.TabIndex = 0;
            this.chkBeefTopping.UseVisualStyleBackColor = true;
            // 
            // chkHamTopping
            // 
            this.chkHamTopping.AutoSize = true;
            this.chkHamTopping.Location = new System.Drawing.Point(19, 100);
            this.chkHamTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkHamTopping.Name = "chkHamTopping";
            this.chkHamTopping.Size = new System.Drawing.Size(15, 14);
            this.chkHamTopping.TabIndex = 0;
            this.chkHamTopping.UseVisualStyleBackColor = true;
            // 
            // chkPeppersTopping
            // 
            this.chkPeppersTopping.AutoSize = true;
            this.chkPeppersTopping.Location = new System.Drawing.Point(272, 29);
            this.chkPeppersTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkPeppersTopping.Name = "chkPeppersTopping";
            this.chkPeppersTopping.Size = new System.Drawing.Size(15, 14);
            this.chkPeppersTopping.TabIndex = 0;
            this.chkPeppersTopping.UseVisualStyleBackColor = true;
            // 
            // chkPepperoniTopping
            // 
            this.chkPepperoniTopping.AutoSize = true;
            this.chkPepperoniTopping.Location = new System.Drawing.Point(19, 64);
            this.chkPepperoniTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkPepperoniTopping.Name = "chkPepperoniTopping";
            this.chkPepperoniTopping.Size = new System.Drawing.Size(15, 14);
            this.chkPepperoniTopping.TabIndex = 0;
            this.chkPepperoniTopping.UseVisualStyleBackColor = true;
            // 
            // chkChikenTopping
            // 
            this.chkChikenTopping.AutoSize = true;
            this.chkChikenTopping.BackColor = System.Drawing.Color.Red;
            this.chkChikenTopping.Location = new System.Drawing.Point(19, 29);
            this.chkChikenTopping.Margin = new System.Windows.Forms.Padding(5);
            this.chkChikenTopping.Name = "chkChikenTopping";
            this.chkChikenTopping.Size = new System.Drawing.Size(15, 14);
            this.chkChikenTopping.TabIndex = 0;
            this.chkChikenTopping.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(636, 255);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Sub Total:";
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.Location = new System.Drawing.Point(751, 250);
            this.txtSubTotal.Margin = new System.Windows.Forms.Padding(5);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.ReadOnly = true;
            this.txtSubTotal.Size = new System.Drawing.Size(164, 26);
            this.txtSubTotal.TabIndex = 1;
            this.txtSubTotal.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(655, 297);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tax 9%:";
            // 
            // txtTax
            // 
            this.txtTax.Location = new System.Drawing.Point(751, 295);
            this.txtTax.Margin = new System.Windows.Forms.Padding(5);
            this.txtTax.Name = "txtTax";
            this.txtTax.ReadOnly = true;
            this.txtTax.Size = new System.Drawing.Size(164, 26);
            this.txtTax.TabIndex = 1;
            this.txtTax.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(673, 345);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Total:";
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(751, 340);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(5);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(164, 26);
            this.txtTotal.TabIndex = 1;
            this.txtTotal.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.Location = new System.Drawing.Point(16, 414);
            this.btnExit.Margin = new System.Windows.Forms.Padding(5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(125, 50);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnOrder
            // 
            this.btnOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnOrder.Location = new System.Drawing.Point(357, 414);
            this.btnOrder.Margin = new System.Windows.Forms.Padding(5);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(194, 50);
            this.btnOrder.TabIndex = 3;
            this.btnOrder.Text = "Order";
            this.btnOrder.UseVisualStyleBackColor = false;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // lblNamOutPut
            // 
            this.lblNamOutPut.AutoSize = true;
            this.lblNamOutPut.Location = new System.Drawing.Point(655, 178);
            this.lblNamOutPut.Name = "lblNamOutPut";
            this.lblNamOutPut.Size = new System.Drawing.Size(0, 20);
            this.lblNamOutPut.TabIndex = 4;
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(184, 414);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(125, 50);
            this.btnWrite.TabIndex = 5;
            this.btnWrite.Text = "Write";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(935, 474);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.lblNamOutPut);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.gbxTodaySpecials);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTax);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSubTotal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbxTodaySpecials.ResumeLayout(false);
            this.gbxTodaySpecials.PerformLayout();
            this.gbxToppings.ResumeLayout(false);
            this.gbxToppings.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.GroupBox gbxTodaySpecials;
        private System.Windows.Forms.RadioButton radioSupreme;
        private System.Windows.Forms.RadioButton radioVeggie;
        private System.Windows.Forms.RadioButton radioMeat;
        private System.Windows.Forms.GroupBox gbxToppings;
        private System.Windows.Forms.CheckBox chkPorkTopping;
        private System.Windows.Forms.CheckBox chkPurCherryTopping;
        private System.Windows.Forms.CheckBox chkOnionTopping;
        private System.Windows.Forms.CheckBox chkSpinachTopping;
        private System.Windows.Forms.CheckBox chkMushroomTopping;
        private System.Windows.Forms.CheckBox chkBeefTopping;
        private System.Windows.Forms.CheckBox chkHamTopping;
        private System.Windows.Forms.CheckBox chkPeppersTopping;
        private System.Windows.Forms.CheckBox chkPepperoniTopping;
        private System.Windows.Forms.CheckBox chkChikenTopping;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSubTotal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Label lblNamOutPut;
        private System.Windows.Forms.Button btnWrite;
    }
}

